#include <iostream>

// make sure we find headers
#include "slsimlib.h"

int main(int argc, char* argv[])
{
	std::cout << "Hello World" << std::endl;
	
	// make sure we link the libraries
	PixelMap map;
	
	return 0;
}

